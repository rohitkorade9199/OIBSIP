# TemperatureConverter
###### A simple website that converts temperature.


Temperatures availables:
- Celsius degrees.
- Fahrenheit degrees.
- Kelvin.
- Rankine
